create database VENTAS
use VENTAS
create table EMPLEADO(
id_empleado numeric(10) primary key not null,
Nombre_emp varchar(90) not null,
Usuario varchar (40) not null,
Contra varchar (40) not null,
DPI numeric(20) not null,
Fecha_ingreso datetime,
telefono numeric (10),
Estado numeric(10))

create table PROVEEDORES(
id_prove numeric (10) primary key not null,
Nombre_prov varchar(40) not null,
Tel_prov numeric (16) not null,
direc_prov varchar (40) not null,
)

create table PRODUCTO(
id_prod numeric (10) primary key not null,
Nombre_prod varchar (60) not null,
Precio decimal(10,2) not null,
Stock numeric (38),
Estado varchar (1) not null,
id_prov numeric (10) references PROVEEDORES not null
)

create table VENTA(
id_venta numeric(11) primary key not null,
cliente varchar(30),
empleado numeric(10) references EMPLEADO not null,
fecha_venta datetime not null,
monto decimal(10,2))

create table DETALLE_VENTA(
ventas_idvent numeric(11) references VENTA not null,
Descripcion varchar(30) not null,
PrecioVenta decimal(10,2) not null)


INSERT INTO EMPLEADO VALUES (1,'Pablo de Le�n','Hoffeins','123','67589','02/02/2002',12345,1)